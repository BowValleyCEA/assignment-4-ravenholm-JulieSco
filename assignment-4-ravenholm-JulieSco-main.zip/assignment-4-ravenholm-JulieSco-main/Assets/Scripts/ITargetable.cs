﻿
public interface ITargetable
{
    void Target();
    void StopTarget();
}
